RYVORA — Android build starter (phone-friendly)

WHAT THIS IS
- The current integrated RYVORA HTML prototype placed in www/index.html.
- Capacitor configuration and a GitHub Actions workflow that can build a DEBUG APK in the cloud.
- This ZIP itself is source code, NOT an APK and NOT a production-ready app.

PHONE-ONLY ROUTE (requires a GitHub account and internet)
1. Download and extract this ZIP on your phone.
2. Create a new GitHub repository named r y v o r a (without spaces), or another name you prefer.
3. Upload the CONTENTS of this folder to the repository root. Ensure package.json, capacitor.config.json, www/ and .github/ are at the root.
4. In GitHub repository Settings, check Actions are allowed. For a public repository, Actions usage is generally free within GitHub's current policies/limits; limits and availability can change.
5. Open the Actions tab and choose “Build RYVORA Android APK”. Press “Run workflow” (or push to main).
6. When the run succeeds, open that workflow run and download the “RYVORA-debug-APK” artifact. Extract the artifact ZIP to get app-debug.apk.
7. Transfer/open the APK on your Android phone. Android may ask permission to install from that source; only install APKs from a repository you control and trust.

IMPORTANT LIMITATIONS
- Build workflow may need maintenance if Android/Capacitor tool versions change.
- This creates a DEBUG APK for testing, not a signed Play Store release.
- GPS uses phone location, not bike odometer. Test permissions and accuracy carefully.
- Real Bajaj Bluetooth/cluster data is NOT implemented. Pairing and call notifications do not automatically grant third-party apps access to bike telemetry.
- Real OTP/login, cloud sync, live friend sharing, push notifications and production security are not implemented.
- Do not upload secrets or personal data to a public repository. Make the repository private if you prefer; check current GitHub Actions limits for private repos.
